<?php $__env->startSection('tittle', 'AcheAki - Principal'); ?>

<?php $__env->startSection('content'); ?>

<img class="img-nav" src="<?php echo e(asset('img/Rectangle 1267.png')); ?>" alt="" srcset="" />
<div class="h3-over-img">
    <h1 class="text-hover">Mesmo perdido, achamos, faça a sua pesquisa</h1>
    <form class="search-box">
        <input class="search" type="search" placeholder="Pesquisar Item" aria-label="Search">
        <button class="search-buttton" type="submit">Pesquisar</button>
    </form>
</div>


Conteudo, Ujar jquery

<div class="tudo">
    <div id="About" class="baixo">
        <div class="txt-imge">


            <h6 class="h6h">Quem Somos & o que fizemos </h6>
            <div class="h-txt">
                Somos uma agência angolana que se que com promete com o bem estar da população, e visando isso
                pretamos o serviço de proteger os teus bens perdidos, e fazer chegar ao devido proprietario os bens
                perdidos, a segurando a  segurança dos bens, e dos entes envolvidos no processo

            </div>
            <div class="about">Sobre Nós</div>
        </div>
        <img class="img-txt" src="<?php echo e(asset('img/about.png')); ?>" alt="" srcset="" />
    </div>
</div>

<div class="num-blue container-fluid" id="Contact">
    <div class="row">
        <div class="num-blue-box">
            <p class="p-blue-box"><b>Estatisticas</b></p>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <p class="p-des-blue">Achados</p>
            <p class="blu-numb"><b>293</b></p>
        </div>
        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <p class="p-des-blue">Perdidos</p>
            <p class="blu-numb"><b>453</b></p>
        </div>
        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <p class="p-des-blue">Entregues</p>
            <p class="blu-numb"><b>89</b></p>
        </div>
    </div>
</div>

<div class="tudo">
    <div class="contacte">
        <p class="contact-p">
            Contacte-nos
        </p>


        <form action="">
            <input class="text-contac" type="text" name="Contacto" id=""><br>

            <textarea class="areatex" name="" id="" cols="30" rows="10"></textarea><br>

            <button class="button-contac" type="submit">Contact</button>
        </form>
    </div>




</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AcheAki\resources\views/index.blade.php ENDPATH**/ ?>