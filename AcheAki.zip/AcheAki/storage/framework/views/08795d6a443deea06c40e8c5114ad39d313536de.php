

<?php $__env->startSection('tittle','Itens Perdidos'); ?>

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/item.css')); ?>">


<div class="corpo container">
    <div class="titulo row">
        <h2 class="itemP">Item <?php echo e($artigos->status); ?></h2>
    </div>
    <div class="resto row">
        <div class="imagem col-sm-12 col-md-6 col-lg-6">
            <img src="img/Rectangle 1267.png" alt="">
            <p class="location"><?php echo e($artigos->local); ?></p>
            <p class="data"><?php echo e($artigos->data); ?></p>
        </div>
        <div class="descri col-sm-12 col-md-6 col-lg-6">
            <h6 class="nomeitem h4"><?php echo e($artigos->item_name); ?></h6>
            <h5 class="descri_titulo">Descrição</h5>
            <p class="descricao_txt text-justify">
                <?php echo e($artigos->descricao); ?>

            </p>
            <input class="button-place btn btn-primary btn" type="button" value="Marcar ponto de encontro">
            <input class="button-place2 btn btn-primary btn" type="button" value="Marcar ponto de Referência">

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/V/Documents/GitHub/AcheAki1/AcheAki/resources/views/item.blade.php ENDPATH**/ ?>