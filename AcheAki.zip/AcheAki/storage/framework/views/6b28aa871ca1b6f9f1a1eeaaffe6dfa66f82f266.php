

<?php $__env->startSection('tittle','Itens Perdidos'); ?>

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/perdidos.css')); ?>">

    <title>Perdidos</title>



    <nav class="navbar navbar-expand-lg navbar-light  fixed-top bg-light">

        <a class="navbar-brand" href="#">LOGO</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

            <ul class="navbar-nav mr-auto">

                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Home </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('achados')); ?>">Achados </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Perdidos </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="tudo mrge1">
        <div class="box_wh1">
            <div class="itens-wth">
                <h6 class="h6h">Pesquisar Item Achado </h6>
                <form class="search-box">
                    <input class="search" type="search" placeholder="Pesquisar Item" aria-label="Search">
                    <button class="search-buttton" type="submit">Pesquisar</button>
                </form>
                <button class="button-search" type="submit">Categoria</button>
            </div>
        </div>
    </div>

    <div class="tudo mrge2 container">
        <div class="box_wh2">
            <div class="itens-wth">
                <h6 class="h6h">Pesquisar Item Achado </h6>
                <form class="search-box">
                    <div class="container register">
                        <div class="row f1">
                            <div class="col-md-6 col-sm-6">
                                <label for="o que você achou?">O que você achou?</label>
                                <input class="form-control form-control-sm" type="text"><br>
                                <label for="">Descrição</label>
                                <textarea class="form-control form-control-sm" rows="6"></textarea> <br>
                                <select class="form-control">
                                    <option>Categoria...</option>
                                    <option>Categoria...</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="">Anexar Foto</label>
                                <input class="form-control-file" type="file" id="ficheiro">
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <h6 class="h6h">Seus Dados</h6> <br>
                        <div class="row f2">
                            <div class="col-md-6 col-sm-6">
                                <label for="Nome">Nome Completo</label>
                                <input class="form-control form-control-sm" type="text"
                                    placeholder="Exemplo: Pedro"><br>
                                <label for="Nome">Telefone</label>
                                <input class="form-control form-control-sm" type="text" placeholder="9XX XXX XXX"><br>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <label for="Nome">Email</label>
                                <input class="form-control form-control-sm" type="email"
                                    placeholder="Exemplo@exemplo.com"><br>
                            </div>
                        </div>
                        <button class="btn btn-primary btn_confirmar align-self-center" type="submit">Confirmar</button>
                    </div>
            </div>
        </div>
        </form>
    </div>
    </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AcheAki\resources\views/perdidos.blade.php ENDPATH**/ ?>